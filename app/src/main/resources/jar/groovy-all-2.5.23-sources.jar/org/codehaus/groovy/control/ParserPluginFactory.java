/*
 *  Licensed to the Apache Software Foundation (ASF) under one
 *  or more contributor license agreements.  See the NOTICE file
 *  distributed with this work for additional information
 *  regarding copyright ownership.  The ASF licenses this file
 *  to you under the Apache License, Version 2.0 (the
 *  "License"); you may not use this file except in compliance
 *  with the License.  You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing,
 *  software distributed under the License is distributed on an
 *  "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 *  KIND, either express or implied.  See the License for the
 *  specific language governing permissions and limitations
 *  under the License.
 */
package org.codehaus.groovy.control;

import org.codehaus.groovy.antlr.AntlrParserPluginFactory;

/**
 * A factory of parser plugin instances
 *
 */
public abstract class ParserPluginFactory {

    /**
     * Creates a new instance of {@link ParserPluginFactory}.
     *
     * <p>The <code>useNewParser</code> parameter is not used, and this method
     * is kept for backward compatibility.
     *
     * @param useNewParser unused.
     * @return the new parser factory.
     * @deprecated use {@link #newInstance()}
     */
    @Deprecated
    public static ParserPluginFactory newInstance(boolean useNewParser) {
        return newInstance();
    }

    /**
     * Creates a new instance of {@link ParserPluginFactory}.
     *
     * @return the new parser factory.
     */
    public static ParserPluginFactory newInstance() {
        return new AntlrParserPluginFactory();
    }

    public abstract ParserPlugin createParserPlugin();
}
